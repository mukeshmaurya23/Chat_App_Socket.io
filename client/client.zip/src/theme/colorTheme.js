export const colorTheme = {
  primary: "#212B36",
  secondary: "#161C24",
  blueChat: "#0162C4",
  messageColor: "rgb(118, 53, 220)",
};
